# Prompt library (Antigravity-ready)

Template: Implement <STEP_ID> — <TITLE>
- Repo: apps/mobile (Expo RN TS) + Supabase
- Output: files with full code, commands, acceptance checklist, pitfalls
