# Git workflow

- main is protected (PR required)
- feature branches: feat/p5-s2-event-crud
- one plan step = one issue + one PR
- PR includes How to test + screenshots for UI
