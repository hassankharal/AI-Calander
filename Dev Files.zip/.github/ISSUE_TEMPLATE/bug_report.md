---
name: Bug report
about: Report a defect
title: "Bug: <short title>"
labels: bug
---

## What happened

## Steps to reproduce
1.
2.
3.
