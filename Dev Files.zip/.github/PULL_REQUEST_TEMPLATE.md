## What

## Why

## How to test
1.
2.
3.

## Screenshots (if UI)

## Checklist
- [ ] CI passes
- [ ] No secrets committed
- [ ] Migrations included (if needed)
- [ ] Docs updated (if schema/contract changed)

Closes #
