﻿module.exports = {
  root: true,
  env: { es2021: true, node: true },
  parser: '@typescript-eslint/parser',
  plugins: ['@typescript-eslint', 'react', 'react-hooks'],
  extends: [
    'eslint:recommended',
    'plugin:react/recommended',
    'plugin:react-hooks/recommended',
    'plugin:@typescript-eslint/recommended',
    'prettier',
  ],
  rules: {
  'react/react-in-jsx-scope': 'off',
},
  settings: { react: { version: 'detect' } },
  ignorePatterns: ['node_modules/', '.expo/', 'web-build/'],
};
